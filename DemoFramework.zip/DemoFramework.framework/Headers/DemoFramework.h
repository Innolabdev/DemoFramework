//
//  DemoFramework.h
//  DemoFramework
//
//  Created by Xevser on 13.02.2018.
//  Copyright © 2018 Medyasoft. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DemoFramework.
FOUNDATION_EXPORT double DemoFrameworkVersionNumber;

//! Project version string for DemoFramework.
FOUNDATION_EXPORT const unsigned char DemoFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DemoFramework/PublicHeader.h>


